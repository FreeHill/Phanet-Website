/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:29:39
 * @Last Modified by: Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:35:14
 */

export { default as CustomCarousel } from './CustomCarousel';
