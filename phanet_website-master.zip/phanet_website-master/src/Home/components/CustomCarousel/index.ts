/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:29:07
 * @Last Modified by: Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:37:04
 */

export { default } from './CustomCarousel';
