/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:34:40
 * @Last Modified by:   Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:34:40
 */

export { default as Home } from './Home';
