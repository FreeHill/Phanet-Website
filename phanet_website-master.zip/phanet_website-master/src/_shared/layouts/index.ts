/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:33:05
 * @Last Modified by:   Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:33:05
 */

export { default as Main } from './Main';
export { default as Minimal } from './Minimal';
