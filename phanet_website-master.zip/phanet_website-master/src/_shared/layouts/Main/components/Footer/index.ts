/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:31:54
 * @Last Modified by:   Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:31:54
 */

export { default } from './Footer';
