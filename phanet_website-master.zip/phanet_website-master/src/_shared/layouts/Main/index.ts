/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:32:18
 * @Last Modified by:   Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:32:18
 */

export { default } from './Main';
