/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:32:56
 * @Last Modified by:   Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:32:56
 */

export { default } from './Minimal';
