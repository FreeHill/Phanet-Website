/*
 * @Author: Dieu-Donne Nazzah
 * @Date: 2020-05-27 01:31:13
 * @Last Modified by:   Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-27 01:31:13
 */

export { default } from './RouteWithLayout';
