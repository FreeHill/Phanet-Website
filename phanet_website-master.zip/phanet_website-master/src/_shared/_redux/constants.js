/*
 * @Author: Nazzah Dieu-Donne
 * @Date: 2019-02-04 19:06:44
 * @Last Modified by: Dieu-Donne Nazzah
 * @Last Modified time: 2020-05-26 05:44:37
 */

export const Constants = {
	actions: {
		LOADING: 'LOADING',
	},
};
